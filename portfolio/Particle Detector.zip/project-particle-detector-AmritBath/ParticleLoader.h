// PHYS 30762 Programming in C++
// Author: Amrit Bath
// Date: April 2025
// Description: Module for loading particles from a file

#pragma once

#include "Particles/Electron.h"
#include "Particles/Muon.h"
#include "Particles/Photon.h"
#include "Particles/Neutrino.h"

class ParticleLoader {
public:
  static std::vector<std::shared_ptr<Particle>> load(const std::string& filename = "particles.txt") {
    std::vector<std::shared_ptr<Particle>> particles;
    std::ifstream file(filename);

    if (!file.is_open()) {
      std::cerr << "\033[33mWarning:\033[0m Could not open '" << filename << "'. Using fallback particle generation.\n";
      return particles;
    }

    std::string line;
    while (std::getline(file, line)) {
      std::istringstream iss(line);
      std::string type;
      double energy;

      if (std::getline(iss, type, ',') && iss >> energy) {
        if (type == "electron")
          particles.push_back(std::make_shared<Electron>(energy));
        else if (type == "muon")
          particles.push_back(std::make_shared<Muon>(energy));
        else if (type == "photon")
          particles.push_back(std::make_shared<Photon>(energy));
        else if (type == "positron")
           particles.push_back(std::make_shared<Electron>(energy, true));
        else if (type == "neutrino")
          particles.push_back(std::make_shared<Neutrino>(energy));
        else
          std::cerr << "\033[31mUnknown particle type:\033[0m " << type << "\n";
      }
    }

    return particles;
  }
};
