// PHYS 30762 Programming in C++
// Author: 10899510 - Amrit Bath
// Date: May 2025
// Description: Common includes header file
// This file includes all the necessary standard libraries and headers
// that are commonly used across different modules in the project.


#pragma once

#include <iostream>      // For input and output operations
#include <cmath>         // For mathematical functions such as std::sqrt and std::pow
#include <string>        // For string manipulation
#include <fstream>       // For file input and output operations
#include <iomanip>       // For input/output manipulators like std::setw and std::setprecision
#include <vector>        // For using the std::vector container
#include <map>           // For using the std::map container
#include <list>          // For using the std::list container
#include <memory>        // For smart pointers like std::shared_ptr and std::unique_ptr
#include <numeric>       // For using std::accumulate
#include <algorithm>     // For using algorithms like std::sort and std::find
#include <random>        // For random number generation
#include <chrono>        // For high-resolution clock
#include <stdexcept>     // For exception handling
#include <unordered_map> // For using std::unordered_map
#include <sstream>       // For string stream operations

