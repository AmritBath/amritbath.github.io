# Particle Detector Simulation in C++

## Project Overview

This project simulates a simplified high-energy particle detector inspired by real-world systems like the ATLAS and CMS experiments at CERN. Using modern C++ and object-oriented programming, it models particle creation, interaction with detector subsystems, energy deposition, and particle type inference.

The simulation reflects realistic physics features, including tau decay pathways, energy smearing, probabilistic detection efficiencies, and missing energy estimation.

---

## Features

- **Object-Oriented Design:** Abstract base classes for particles and detectors.
- **Dynamic Memory Management:** Safe handling with `std::shared_ptr` smart pointers.
- **Physical Modelling:**
  - Four-momentum encapsulation (`E`, `p_x`, `p_y`, `p_z`) for each particle.
  - Tau lepton decay into leptonic or hadronic products.
  - Photon interactions via Compton scattering, photoelectric effect, and pair production.
- **Statistical Realism:**
  - Detection efficiencies and energy smearing using STL random distributions.
- **Inference Logic:**
  - Rule-based identification of particles based on detector hit patterns.
  - Missing energy estimation for neutrinos and undetected particles.
- **Extensibility:**
  - Modular design allows easy addition of new detectors or interaction types.

---

## Project Structure

Files are grouped into folders based on their roles: particle classes in Particles/, detector subsystems in Detector/, and interaction logic and utilities in Interactions/. This structure supports modularity, clean memory management, and future extensibility of the simulation.

- If `Particles.txt` is provided, the program will load particle configurations from the file.
- Otherwise, it will generate random initial particles.

4. **Output:**
- Terminal output showing particle properties, detector responses, and inferred types.
- CSV log file (`detection_log.csv`) containing true/measured energies and inference results for post-processing.

---

## Advanced Functionality

- Smart pointers (`std::shared_ptr`) used throughout for safe dynamic allocation.
- Modular DetectorManager architecture for flexible detector configurations.
- Tau decay pathways selected probabilistically at runtime.
- Statistical modelling of detection inefficiencies and energy loss.
- Fully extensible to additional physics processes, sub-detectors, or spatial tracking upgrades.

---

## Future Extensions (Possible Directions)

- Full 3D spatial propagation and track curvature simulation.
- Integration with visualization libraries (e.g., ROOT, Matplotlib).
- Parallel event simulation for large datasets.
- Magnetic field effects on charged particle trajectories.

---

## Compilation & Execution

1. **Compile**  
   ```bash
   make

(This runs: g++-11 -std=c++17 -g *.cpp **/*.cpp -o main)

2. **Clean build artifacts**
make clean

3. **Run the simulation**
./main

---

## References

- [ATLAS Experiment, CERN](https://home.cern/science/experiments/atlas)
- [CMS Experiment, CERN](https://home.cern/science/experiments/cms)
- Frank Close, *Particle Physics: A Very Short Introduction* (OUP, 2004)
- David J. Griffiths, *Introduction to Elementary Particles* (Wiley-VCH, 2008)
- Particle Data Group, *Review of Particle Physics* (2024)
- Georges Aad et al. “Observation of a new particle in the search for the Standard Model Higgs boson with
  the ATLAS detector at the LHC”. In: Physics Letters B 716.1 (2012), pp. 1–29.
- Glen Cowan. Statistical Data Analysis. Oxford Science Publications, 1998.
- Lisa Randall. Warped Passages: Unraveling the Mysteries of the Universe’s Hidden Dimensions
  HarperCollins, 2005.
---

**Author:**  
Amrit Bath  
University of Manchester  
April 2025
