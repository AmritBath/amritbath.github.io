// PHYS 30762 Programming in C++
// Author: 10899510 - Amrit Bath
// Date: April 2025
// Lepton header file


#pragma once

#include "Particle.h"
#include "../Interactions/Constants.h"
#include "../Interactions/FourMomentum.h"

class Lepton : public Particle 
{
protected:
  // Member variables
  std::string type;
  int charge;
  double velocity;
  double beta;
  bool is_antiparticle;
  FourMomentum four_momentum;

public:
  // Constructor and Destructor
  Lepton();
  Lepton(double rest_mass, double energy, int charge, bool is_antiparticle);
  Lepton(std::string particle_type, bool is_antiparticle, double velocity);
  virtual ~Lepton();

  // Member functions
  void set_velocity(double velocity);
  std::string get_type() const override;
  int get_charge() const override;
  double get_velocity() const;
  double get_beta() const;
  double gamma() const;

  // Setters and Getters
  const FourMomentum& get_four_momentum() const;
  void print() const override;

  bool get_is_antiparticle() const 
  {
   return is_antiparticle; 
  }

};
