// PHYS 30762 Programming in C++
// Author: 10899510 - Amrit Bath
// Date: April 2025
// Particle class implementation
// Description: Implementation of the Particle class, which serves as a base class for various particle types.
// It includes methods for getting and setting particle properties, as well as a static method to get the particle count.

#include "Particle.h"

// Constructor for Particle class
double Particle::get_rest_mass() const 
{
  return rest_mass;
}

// Function to get the energy of the particle
double Particle::get_energy() const 
{
  return energy;
}

void Particle::set_energy(double e) 
{
  energy = e;
  // Set initial energy only if it's the first assignment
  if (initial_energy == 0.0) initial_energy = e;
}


// Function to get the particle ID
int Particle::particle_count = 0;


Particle::~Particle() 
{
  --particle_count;
}

int Particle::get_particle_count() 
{
  return particle_count;
}

int Particle::id_counter = 0;

