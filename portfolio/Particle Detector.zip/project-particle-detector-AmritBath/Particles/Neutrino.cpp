// PHYS 30762 Programming in C++
// Author: 10899510 - Amrit Bath
// Date: April 2025
// Neutrino class implementation
// Description: Implementation of the Neutrino class, which represents a neutrino particle.


#include "Neutrino.h"
#include "../Interactions/Verbose.h"

// Neutrino constructor
Neutrino::Neutrino(double energy)
  : Particle(0.0, energy), four_momentum(energy, 0.0, 0.0, energy) 
  {
  spin = 0.5f;
  if(VERBOSE)
    std::cout << "\033[32mConstructing neutrino\033[0m\n";
}

// Destructor
std::string Neutrino::get_type() const 
{
  return "neutrino";
}

// Get the four-momentum of the neutrino
const FourMomentum& Neutrino::get_four_momentum() const 
{
  return four_momentum;
}

// Print the data of the neutrino
void Neutrino::print() const 
{
  std::cout 
  << "Neutrino | Energy: " << energy << " keV\n"
  << "Particle ID: " << get_id() << "\n"
  << "Spin: " << spin << "\n";
  if(VERBOSE)
    four_momentum.print();
}
