// PHYS 30762 Programming in C++
// Author: 10899510 - Amrit Bath
// Date: April 2025
// Photon header file

#pragma once

#include "Particle.h"
#include "../Interactions/FourMomentum.h"

class Electron;  // Forward declaration

class Photon : public Particle 
{
private:
  std::vector<std::shared_ptr<Electron>> electrons;
  FourMomentum four_momentum;

public:
  Photon(double energy);

  void add_electron(std::shared_ptr<Electron> e);
  const std::vector<std::shared_ptr<Electron>>& get_electrons() const;

  std::string get_type() const override;
  void print() const override;

  friend double photoelectric_effect(const Photon& p);
  friend void compton_scattering(Photon& p, double angle_deg);
  friend std::vector<std::shared_ptr<Electron>> pair_production(const Photon& p);

  const FourMomentum& get_four_momentum() const;
};
