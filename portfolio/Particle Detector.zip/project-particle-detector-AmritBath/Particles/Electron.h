// PHYS 30762 Programming in C++
// Author: 10899510 - Amrit Bath
// Date: April 2025
// Electron header file

#pragma once
#include "Lepton.h"


// Electron class represents an electron or positron 
class Electron : public Lepton 
{
public:
  Electron(double energy, bool is_antiparticle = false);
  std::string get_type() const override;
};
