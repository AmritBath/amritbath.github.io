// PHYS 30762 Programming in C++
// Author: 10899510 - Amrit Bath
// Date: April 2025
// Photon class implementation
// Description: Implementation of the Photon class, which represents a photon particle in a particle detection system.

#include "Photon.h"
#include "Electron.h"
#include "../Interactions/Verbose.h"

// Constructor for Photon class
Photon::Photon(double energy)
  : Particle(0.0, energy), four_momentum(FourMomentum(energy, 0.0, 0.0, energy))
{
  spin = 0.5f;
  if(VERBOSE)
    std::cout << "\033[32mConstructing photon\033[0m\n";
}

// Destructor for Photon class
void Photon::add_electron(std::shared_ptr<Electron> e) 
{
  electrons.push_back(e);
}

// Function to add an electron to the photon
const std::vector<std::shared_ptr<Electron>>& Photon::get_electrons() const 
{
  return electrons;
}

// Function to get the type of particle (photon)
std::string Photon::get_type() const 
{
  return "photon";
}

// Function to get the four-momentum of the photon
const FourMomentum& Photon::get_four_momentum() const 
{
  return four_momentum;
}

// Function to print the data of the photon
void Photon::print() const 
{
  std::cout 
  << "Photon | Energy: " << energy << " keV\n"
  << "Spin: " << spin << "\n"
  << "Particle ID: " << get_id() << "\n";
  if(VERBOSE) four_momentum.print();
}