// PHYS 30762 Programming in C++
// Author: 10899510 - Amrit Bath
// Date: April 2025
// Muon header file

#pragma once
#include "Lepton.h"

class Muon : public Lepton 
{
public:
  // Declaration only
  Muon(double energy, bool is_antiparticle = false);  
  std::string get_type() const override;              
};
