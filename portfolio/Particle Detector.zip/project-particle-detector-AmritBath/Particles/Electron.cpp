// PHYS 30762 Programming in C++
// Author: 10899510 - Amrit Bath
// Date: April 2025
// Electron class implementation
// Description: Implementation of the Electron class, which represents an electron or positron (anti-electron).


#include "Electron.h"

// Constructor for Electron class
Electron::Electron(double energy, bool is_antiparticle)
  : Lepton("electron", is_antiparticle, 0.0)
{
  spin = 0.5f;
  set_energy(energy);
}

// Function to get the type of particle (electron or anti-electron)
std::string Electron::get_type() const 
{
  return is_antiparticle ? "positron" : "electron"; 
}

