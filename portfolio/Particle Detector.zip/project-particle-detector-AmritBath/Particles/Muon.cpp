// PHYS 30762 Programming in C++
// Author: 10899510 - Amrit Bath
// Date: April 2025
// Muon implementation file

#include "Muon.h"

// Constructor for Muon class
Muon::Muon(double energy, bool is_antiparticle)
  : Lepton("muon", is_antiparticle, 2.0e8)  
{
  spin = 0.5f;
  set_energy(energy);
}

// Function to get the type of particle (muon or anti-muon)
std::string Muon::get_type() const 
{
  return is_antiparticle ? "anti-muon" : "muon";
}
