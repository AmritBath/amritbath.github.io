// PHYS 30762 Programming in C++
// Author: 10899510 - Amrit Bath
// Date: April 2025
// Neutrino header file

#pragma once

#include "Particle.h"
#include "../Interactions/FourMomentum.h"

class Neutrino : public Particle 
{
private:
  FourMomentum four_momentum;

public:
  Neutrino(double energy);

  std::string get_type() const override;
  void print() const override;
  const FourMomentum& get_four_momentum() const;
};
