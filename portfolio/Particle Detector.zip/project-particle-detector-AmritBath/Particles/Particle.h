// PHYS 30762 Programming in C++
// Author: 10899510 - Amrit Bath
// Date: April 2025
// Particle header file

#pragma once

#include "../common_includes.h"

class Particle 
{
protected:
  double rest_mass;
  double energy;
  double initial_energy;  
  static int particle_count;
  int charge;
  float spin;
  int id;
  static int id_counter;

public:
  Particle(double rm, double e, float s = 0.0f)
  : rest_mass(rm), energy(e), spin(s), id(++id_counter)
{
  ++particle_count;
}


  virtual ~Particle();
  static int get_particle_count();

  double get_rest_mass() const;
  double get_energy() const;
  void set_energy(double e);
  void set_initial_energy(double e) { initial_energy = e; }


  double get_initial_energy() const { return initial_energy; }

  virtual std::string get_type() const = 0;
  virtual void print() const = 0;

  virtual int get_charge() const { return charge; }
  int get_id() const { return id; }
  float get_spin() const { return spin; }

};
