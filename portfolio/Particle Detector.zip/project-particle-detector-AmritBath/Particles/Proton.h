// PHYS 30762 Programming in C++
// Author: 10899510 - Amrit Bath
// Date: April 2025
// Proton header file
// Description: Header file for the Proton class, which represents a proton particle in a particle detection system.

#pragma once

#include "Particle.h"
#include "../Interactions/FourMomentum.h"

class Proton : public Particle 
{
private:
  FourMomentum four_momentum;

public:
  Proton(double velocity);

  std::string get_type() const override;
  void print() const override;
  const FourMomentum& get_four_momentum() const;
};
