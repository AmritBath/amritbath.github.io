// PHYS 30762 Programming in C++
// Author: 10899510 - Amrit Bath
// Date: April 2025
// Proton class implementation
// Description: Implementation of the Proton class, which represents a proton particle in a particle detection system.

#include "Proton.h"
#include "../Interactions/Constants.h"
#include "../Interactions/Verbose.h"


// Constructor for Proton class
Proton::Proton(double velocity)
  : Particle(PROTON_MASS, 0.0) 
  {
  spin = 0.5f;
  energy = std::sqrt(rest_mass * rest_mass + velocity * velocity);
  four_momentum = FourMomentum::from_mass_and_velocity(rest_mass, 0.0, 0.0, velocity);

  if(VERBOSE)
  std::cout << "\033[32mConstructing proton\033[0m\n";
}

// Function to set the type of the particle
std::string Proton::get_type() const 
{
  return "proton";
}

// Function to get the four-momentum of the proton
const FourMomentum& Proton::get_four_momentum() const 
{
  return four_momentum;
}

// Function to print the data of the proton
void Proton::print() const 
{
  std::cout << "Particle Type: proton\n"
    << "Mass: " << rest_mass << " MeV\n"
    << "Energy: " << energy << " keV\n"
    << "Spin: " << spin << "\n"
    << "Particle ID: " << get_id() << "\n";
  if(VERBOSE)
  four_momentum.print();
}
