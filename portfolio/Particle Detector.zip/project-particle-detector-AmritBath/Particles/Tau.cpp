// PHYS 30762 Programming in C++
// Author: 10899510 - Amrit Bath
// Date: April 2025
// Tau class implementation
// Description: Implementation of the Tau class, which represents a tau lepton particle.

#include "Tau.h"
#include "../Interactions/Constants.h"
#include "../Interactions/Verbose.h"

// Constructor for Tau class
Tau::Tau(double velocity)
  : Lepton("tau", false, velocity) 
  {
  spin = 0.5f;
  rest_mass = TAU_MASS;
  set_velocity(velocity);
  energy = std::sqrt(rest_mass * rest_mass + velocity * velocity);
  four_momentum = FourMomentum::from_mass_and_velocity(rest_mass, 0.0, 0.0, velocity);

  if(VERBOSE)
    std::cout << "\033[32mConstructing tau\033[0m\n";
}

// Destructor for Tau class
std::string Tau::get_type() const 
{
  return "tau";
}

// Function to get the four-momentum of the tau particle
const FourMomentum& Tau::get_four_momentum() const 
{
  return four_momentum;
}

// Function to print the data of the tau particle
void Tau::print() const 
{
  std::cout << "Particle Type: tau\n"
      << "Mass: " << rest_mass << " MeV\n"
      << "Charge: -1e\n"
      << "Velocity: " << velocity << " m/s\n"
      << "Spin: " << spin << "\n"
      << "Particle ID: " << get_id() << "\n";
  if(VERBOSE)
    four_momentum.print();
}
