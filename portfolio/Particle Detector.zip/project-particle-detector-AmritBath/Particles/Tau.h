// PHYS 30762 Programming in C++
// Author: 10899510 - Amrit Bath
// Date: April 2025
// Tau header file

#pragma once

#include "Lepton.h"
#include "../Interactions/FourMomentum.h"

class Tau : public Lepton 
{
public:
  Tau(double velocity);

  std::string get_type() const override;
  const FourMomentum& get_four_momentum() const;
  void print() const override;
};
