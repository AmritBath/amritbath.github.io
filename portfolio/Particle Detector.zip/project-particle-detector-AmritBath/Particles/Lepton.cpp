// PHYS 30762 Programming in C++
// Author: 10899510 - Amrit Bath
// Date: April 2025
// Lepton class implementation
// Description: Implementation of the Lepton class, which represents a lepton particle in a particle detection system.

#include "Lepton.h"
#include "../Interactions/Verbose.h"

// Default constructor 
Lepton::Lepton()
  : Particle(0.0, 0.0), type("unknown"), charge(0), velocity(0.0), beta(0.0), is_antiparticle(false),
  four_momentum(FourMomentum(0.0, 0.0, 0.0, 0.0))
{
  if(VERBOSE)
  std::cout << "\033[32mConstructing particle\033[0m: unknown" << std::endl;
}


// Lepton constructor with parameters
Lepton::Lepton(double rest_mass, double energy, int charge, bool is_antiparticle)
  : Particle(rest_mass, energy),
    charge(charge),
    velocity(0.0),
    beta(0.0),
    is_antiparticle(is_antiparticle),
    four_momentum(energy, 0.0, 0.0, 0.0)
{
  if(VERBOSE)
  std::cout << "\033[32mConstructing lepton\033[0m (custom init)\n";
}

// Lepton constructor with particle type and velocity
Lepton::Lepton(std::string particle_type, bool is_antiparticle, double vel)
  : Particle(0.0, 0.0), type(particle_type), is_antiparticle(is_antiparticle)
{
  if(type == "electron") 
  {
    type = is_antiparticle ? "positron" : "electron";
    rest_mass = ELECTRON_MASS;
  } 
  else if(type == "muon" || type == "anti-muon") 
  {
    rest_mass = MUON_MASS;
  } 
  else 
  {
    rest_mass = 0.0;
  }

  charge = is_antiparticle ? +1 : -1;
  set_velocity(vel);
  energy = std::sqrt(rest_mass * rest_mass + velocity * velocity);  // Total energy approx
  four_momentum = FourMomentum::from_mass_and_velocity(rest_mass, 0.0, 0.0, velocity);

  if(VERBOSE)
  std::cout << "\033[32mConstructing particle\033[0m: " << get_type() << std::endl;
}

// Destructor
Lepton::~Lepton() 
{
  std::string type_str = get_type();
  if(type_str.empty()) type_str = "interaction progenitor";
  if(VERBOSE)
  std::cout << "\033[31mDestructing particle\033[0m: " << get_type() << std::endl;
}

// Getters and Setters
std::string Lepton::get_type() const 
{
  return type;
}

int Lepton::get_charge() const 
{
   return charge; 
  }
double Lepton::get_velocity() const 
{
   return velocity; 
  }
double Lepton::get_beta() const 
{
   return beta; 
  }
double Lepton::gamma() const 
{
   return energy / rest_mass;
  }

const FourMomentum& Lepton::get_four_momentum() const 
{
  return four_momentum;
}

// Print data
void Lepton::print() const 
{
  std::cout.precision(3);
  std::cout << "Particle Type: " << get_type() << "\n"
    << "Mass: " << rest_mass << " MeV\n"
    << "Charge: " << charge << "e\n"
    << "Velocity: " << velocity << " m/s\n"
    << "Beta: " << beta << "\n"
    << "Gamma: " << gamma() << "\n"
    << "Spin: " << spin << "\n"
    << "Particle ID: " << get_id() << "\n";

  if(VERBOSE) four_momentum.print();
  std::cout << "\n";
} 

// Set velocity and update beta and four-momentum
void Lepton::set_velocity(double vel) 
{
  try 
  {
  if(vel > LIGHT_SPEED) 
  {
    throw std::invalid_argument("Velocity exceeds speed of light");
  }
  velocity = vel;
  beta = velocity / LIGHT_SPEED;
  four_momentum = FourMomentum::from_mass_and_velocity(rest_mass, 0.0, 0.0, velocity);
  }
   catch (const std::invalid_argument& e) 
  {
    std::cerr << "[Exception caught] " << e.what() << ", setting velocity to safe value.\n";
    velocity = BELOW_LIGHT_SPEED;
    beta = velocity / LIGHT_SPEED;
  }
}
