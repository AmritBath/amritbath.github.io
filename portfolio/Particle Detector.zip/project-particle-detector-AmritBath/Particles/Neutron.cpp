// PHYS 30762 Programming in C++
// Author: 10899510 - Amrit Bath
// Date: April 2025
// Description: Implementation of the Neutron class, which represents a neutron particle.


#include "Neutron.h"
#include "../Interactions/Constants.h"
#include "../Interactions/Verbose.h"


Neutron::Neutron(double velocity)
  // Constructor for Neutron class
  : Particle(NEUTRON_MASS, 0.0) 
  {
  spin = 0.5f;
  energy = std::sqrt(rest_mass * rest_mass + velocity * velocity);
  four_momentum = FourMomentum::from_mass_and_velocity(rest_mass, 0.0, 0.0, velocity);

  if(VERBOSE)
    std::cout << "\033[32mConstructing neutron\033[0m\n";
}

std::string Neutron::get_type() const 
{
  return "neutron";
}

// Function to get the four-momentum of the neutron
const FourMomentum& Neutron::get_four_momentum() const 
{
  return four_momentum;
}

// Function to print the neutron's data
void Neutron::print() const 
{
  std::cout << "Particle Type: neutron\n"
      << "Mass: " << rest_mass << " MeV\n"
      << "Energy: " << energy << " keV\n"
      << "Particle ID: " << get_id() << "\n"
      << "Spin: " << spin << "\n";
  if(VERBOSE)
    four_momentum.print();
}
