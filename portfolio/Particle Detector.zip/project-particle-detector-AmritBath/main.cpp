// PHYS 30762 Programming in C++
// Author: 10899510 - Amrit Bath
// Date: April 2025
// Particle Physics Simulator
// Aim : To simulate the interactions of particles with a detector system
// This code includes classes for different types of particles, detectors, and their interactions.
// The simulation initializes particles, sets up detectors, and simulates their interactions.
// It also includes logging and inference capabilities to analyze the results.
// The code is structured to allow for easy extension and modification of particle and detector types.
// The simulation is designed to be run in a console environment and outputs results to the console.
// The code is organized into separate header and source files for better readability and maintainability.

#include "Particles/Electron.h"
#include "Particles/Lepton.h"
#include "Particles/Photon.h"
#include "Particles/Neutrino.h"
#include "Particles/Tau.h"
#include "Particles/Proton.h"
#include "Particles/Neutron.h"
#include "Detector/Tracker.h"
#include "Detector/Calorimeter.h"
#include "Detector/MuonChamber.h"
#include "Detector/DetectorManager.h"
#include "Interactions/Interactions.h"
#include "Interactions/Logger.h"
#include "Interactions/TauDecay.h"
#include "Interactions/InferenceEngine.h"
#include "ParticleLoader.h"


// Missing energy tracking
double missing_energy = 0.0;


// Initialise particles and their properties, either from file or fallback
void initialise_particles(std::vector<std::shared_ptr<Particle>>& particles,
  std::mt19937& gen, std::uniform_real_distribution<>& energy_dist) 
{
std::cout << "\033[1;36m--- Initialising Particles ---\033[0m\n"; 
particles = ParticleLoader::load("Particles.txt");

if(particles.empty()) 
{
  particles.push_back(std::make_shared<Electron>(energy_dist(gen)));
  particles.push_back(std::make_shared<Muon>(2.0e8));  

  std::uniform_real_distribution<> pairproduction_range(1600.0, 1800.0);
  particles.push_back(std::make_shared<Photon>(pairproduction_range(gen)));
}

std::cout << "\n\033[1;36m--- Particle Details ---\033[0m\n";
for(const auto& p : particles) p->print();
}


// Set up detectors and their properties
void setup_detectors(std::shared_ptr<Tracker>& tracker,
       std::shared_ptr<Calorimeter>& calorimeter,
       std::shared_ptr<MuonChamber>& muon_chamber,
       DetectorManager& generic_detector) 
       {
  std::cout << "\n\033[1;36m--- Setting Up Detectors ---\033[0m\n";
  tracker = std::make_shared<Tracker>();
  calorimeter = std::make_shared<Calorimeter>();
  muon_chamber = std::make_shared<MuonChamber>();

  generic_detector.add_detector(tracker);
  generic_detector.add_detector(calorimeter);
  generic_detector.add_detector(muon_chamber);
  generic_detector.turn_all_on();
}


// Create additional particles and their properties
void create_additional_particles(std::vector<std::shared_ptr<Particle>>& particles,
           std::mt19937& gen, std::uniform_real_distribution<>& energy_dist) 
           {
  std::cout << "\n\033[1;36m--- Creating Additional Particles ---\033[0m\n";
  auto neutrino = std::make_shared<Neutrino>(energy_dist(gen));
  neutrino->print();
  particles.push_back(neutrino);

  auto tau = std::make_shared<Tau>(2.0e8);
  tau->print();
  particles.push_back(tau);

  auto proton = std::make_shared<Proton>(1.0e8);
  proton->print();
  particles.push_back(proton);

  auto neutron = std::make_shared<Neutron>(0.0);
  neutron->print();
  particles.push_back(neutron);
}


// Simulate tau decay and its products
void simulate_tau_decay(const std::vector<std::shared_ptr<Particle>>& particles, Logger& logger) 
{
  std::cout << "\n\033[1;36m--- Tau Decay Simulation ---\033[0m\n";
  for(const auto& p : particles) 
  {
  if(p->get_type() == "tau") 
  {
    auto tau_ptr = std::dynamic_pointer_cast<Tau>(p);
    if(tau_ptr) 
    {
    auto decay_products = TauDecay::decay(tau_ptr);
    std::cout << "Decay products:\n";
    for(const auto& prod : decay_products) 
    {
      prod->print();

      logger.log_detection(tau_ptr->get_type(), tau_ptr->get_energy(),
             "tau decay → " + prod->get_type(), true);
    }
    }
  }
  }
}


// Simulate photon interactions and their products
void simulate_photon_interactions(std::shared_ptr<Photon> photon,
          std::vector<std::shared_ptr<Particle>>& particles) 
          {
  std::cout << "\n\033[1;36m--- Simulating Photon Interactions ---\033[0m\n";
  auto produced = pair_production(*photon);
  if(!produced.empty())
   {
  for(const auto& e : produced) 
  {
    e->print();
    particles.push_back(e);
  }
  }
}


// Simulate extra photon effects (photoelectric effect and Compton scattering)
void simulate_extra_photon_effects(std::vector<std::shared_ptr<Particle>>& particles,
           std::mt19937& gen) 
           {
  std::cout << "\n\033[1;36m--- Simulating Extra Photon Effects ---\033[0m\n";
  std::uniform_real_distribution<> photoelectric_range(400.0, 800.0);
  std::uniform_real_distribution<> compton_range(1100.0, 1600.0);
  std::uniform_real_distribution<> angle_dist(10.0, 170.0);
  std::bernoulli_distribution effect_choice(0.5);

  auto photo_photon = std::make_shared<Photon>(photoelectric_range(gen));
  auto compton_photon = std::make_shared<Photon>(compton_range(gen));
  std::vector<std::shared_ptr<Photon>> extra_photons = 
  {
  photo_photon, compton_photon
  };

  for(auto& p : extra_photons) 
  {
  p->print();
  if(effect_choice(gen)) 
  {
    std::cout << "\033[35m[Effect] Applying photoelectric effect...\033[0m\n";
    std::cout << "  Energy deposited: " << photoelectric_effect(*p) << " keV\n";
  } 
  else 
  {
    std::cout << "\033[35m[Effect] Applying Compton scattering...\033[0m\n";
    double angle = angle_dist(gen);
    compton_scattering(*p, angle);
    std::cout << "  Scattered angle: " << angle << " degrees\n";
  }
  particles.push_back(p);
  }
}


// Run the simulation through the detectors
void run_simulation(const std::vector<std::shared_ptr<Particle>>& particles,
      const std::shared_ptr<Tracker>& tracker,
      const std::shared_ptr<Calorimeter>& calorimeter,
      const std::shared_ptr<MuonChamber>& muon_chamber,
      Logger& logger,
      double& total_energy, double& visible_energy) 
{
  std::cout << "\n\033[1;36m--- Running Particles Through Detectors ---\033[0m\n";
  for(const auto& p : particles) 
  {
    const double true_energy = p->get_energy();

    bool t = tracker->detect(p);
    bool c = calorimeter->detect(p);
    bool m = muon_chamber->detect(p);

    double measured_tracker = 0.0;
    double measured_calorimeter = 0.0;
    double measured_muon = 0.0;

    if(t) measured_tracker = tracker->measure_energy(p);
    if(c) measured_calorimeter = calorimeter->measure_energy(p);
    if(m) measured_muon = muon_chamber->measure_energy(p);

    std::cout << "True energy: " << true_energy << " keV\n";
    std::cout << "  Tracker measured:  " << measured_tracker << " keV\n";
    std::cout << "  Calorimeter measured:  " << measured_calorimeter << " keV\n";
    std::cout << "  Muon Chamber measured: " << measured_muon << " keV\n";

    total_energy += true_energy;
    visible_energy += measured_tracker + measured_calorimeter + measured_muon;

    if(!(t || c || m)) 
    {
      missing_energy += true_energy;
    }

    logger.log_detection(p->get_type(), true_energy, tracker->get_type(), t);
    logger.log_detection(p->get_type(), true_energy, calorimeter->get_type(), c);
    logger.log_detection(p->get_type(), true_energy, muon_chamber->get_type(), m);

    std::string inferred = InferenceEngine::infer_particle(t, c, m);
    std::cout << "Inference: " << inferred << " (for particle type: " << p->get_type() << ")\n\n";
  }
}


// Main function to run the simulation
int main() 
{
  std::vector<std::shared_ptr<Particle>> particles;
  std::random_device rd;
  std::mt19937 gen(rd());
  std::uniform_real_distribution<> energy_dist(400.0, 1600.0);

  initialise_particles(particles, gen, energy_dist);

  std::shared_ptr<Tracker> tracker;
  std::shared_ptr<Calorimeter> calorimeter;
  std::shared_ptr<MuonChamber> muon_chamber;
  DetectorManager generic_detector;
  setup_detectors(tracker, calorimeter, muon_chamber, generic_detector);

  Logger logger("detection_log.csv");

  create_additional_particles(particles, gen, energy_dist);
  simulate_tau_decay(particles, logger);
  simulate_photon_interactions(std::dynamic_pointer_cast<Photon>(particles[2]), particles);
  simulate_extra_photon_effects(particles, gen);

  double total_energy = 0.0;
  double visible_energy = 0.0;

  run_simulation(particles, tracker, calorimeter, muon_chamber, logger, total_energy, visible_energy);

  double missing = total_energy - visible_energy;

  std::cout << "\033[1;36m--- Event Energy Summary ---\033[0m\n";
  std::cout << "Total event energy:  " << total_energy << " keV\n";
  std::cout << "Visible detected energy: " << visible_energy << " keV\n";
  std::cout << "Missing energy (undetected/neutrinos): " << missing_energy << " keV\n";
  std::cout << "Consistency check (total-visible): " << missing << " keV\n";

  std::vector<std::shared_ptr<Detector>> all_detectors = 
  {
  tracker, calorimeter, muon_chamber
  };
  int total_detections = std::accumulate(all_detectors.begin(), all_detectors.end(), 0,
  [](int sum, const std::shared_ptr<Detector>& d) 
  {
    return sum + d->get_detection_count();
    });
  std::cout << "Total particles detected across all detectors: " << total_detections << "\n";

  std::cout << "Calorimeter true deposited energy: " << calorimeter->get_true_energy() << " keV\n";
  std::cout << "Calorimeter measured energy:       " << calorimeter->measure_energy(nullptr) << " keV\n";
  std::cout << "Calorimeter error (%):             " 
    << 100.0 * (calorimeter->measure_energy(nullptr) - calorimeter->get_true_energy()) 
    / calorimeter->get_true_energy() << " %\n";


  std::cout << "\n\033[1;36m--- Detector Summary ---\033[0m\n";
  generic_detector.print_all();

  std::cout << "\033[1;32mSimulation complete.\033[0m\n";

  std::cout << "\n\0.33[1:36m-- Desctucting Detectors ---\033[0m\n";
  generic_detector.turn_all_off();
  tracker.reset();
  calorimeter.reset();
  muon_chamber.reset();
  std::cout << "\033[1;31mDetectors destructed.\033[0m\n";
  return 0;
}
