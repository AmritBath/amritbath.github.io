// PHYS 30762 Programming in C++
// Author: 10899510 - Amrit Bath
// Date: April 2025
// Description: Header file for the TauDecay class, which simulates the decay of tau particles into other particles.

#pragma once

#include "../Particles/Tau.h"
#include "../Particles/Neutrino.h"
#include "../Particles/Muon.h"
#include "../Particles/Photon.h"
#include "../Particles/Proton.h"
#include "../Particles/Neutron.h"
#include "../Particles/Electron.h"

class TauDecay 
{
public:
  static std::vector<std::shared_ptr<Particle>> decay(const std::shared_ptr<Tau>& /*tau*/)
  {
    std::vector<std::shared_ptr<Particle>> products;
    
    // Generate a random number to decide the decay mode
    std::random_device rd;
    std::mt19937 gen(rd());
    std::uniform_real_distribution<> dist(0.0, 1.0);
    double r = dist(gen);

    std::cout << "\033[36mDecaying tau...\033[0m\n";

    if(r < 0.5) 
    {
      // Leptonic decay: tau -> muon + neutrino
      auto mu = std::make_shared<Muon>(100.0); 
      auto nu = std::make_shared<Neutrino>(50.0);
      products.push_back(mu);
      products.push_back(nu);
      std::cout << "  Leptonic decay -> muon + neutrino\n";
    } 
    else 
    {
      // Hadronic decay: tau -> proton + neutron + neutrino
      auto p = std::make_shared<Proton>(500.0);
      auto n = std::make_shared<Neutron>(300.0);
      auto nu = std::make_shared<Neutrino>(100.0);
      products.push_back(p);
      products.push_back(n);
      products.push_back(nu);
      std::cout << "  Hadronic decay -> proton + neutron + neutrino\n";
    }

    return products;
  }
};
