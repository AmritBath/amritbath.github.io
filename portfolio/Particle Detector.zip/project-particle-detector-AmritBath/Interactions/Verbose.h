// PHYS 30762 Programming in C++
// Author: 10899510 - Amrit Bath
// Date: April 2025
// Verbose header file
// Description: This header file contains a global constant VERBOSE that can be used to enable or disable verbose output
// in the program. It is set to true by default, but can be changed to false to suppress verbose output.

#pragma once

// Toggle to enable/disable verbose output globally
constexpr bool VERBOSE = true;