// PHYS 30762 Programming in C++
// Author: 10899510 - Amrit Bath
// Date: April 2025
// MeasuredEnergyLogger class implementation
// Description: Implementation of the MeasuredEnergyLogger class, which is responsible for logging the energy
// reports of particles detected in various detectors. It provides a method to log the energy report for a
// given set of particles and their corresponding detectors.

#include "MeasuredEnergyLogger.h"

void MeasuredEnergyLogger::log_energy_report(
  const std::vector<std::shared_ptr<Particle>>& particles,
  const std::shared_ptr<Detector>& tracker,
  const std::shared_ptr<Detector>& calorimeter,
  const std::shared_ptr<Detector>& muon_chamber)
{
  int id = 0;
  for(const auto& p : particles)
  // Log particles energy report 
  {
    std::cout << "\nParticle ID: " << id++
      << " | Type: " << p->get_type()
      << " | Charge: " << (p->get_charge())
      << " | True Energy: " << std::fixed << std::setprecision(1) << p->get_energy() << " keV\n";

    // Detector measurements
    std::cout << "  Detected in tracker:    "
      << tracker->measure_energy(p) << " keV\n";
    std::cout << "  Detected in calorimeter:  "
      << calorimeter->measure_energy(p) << " keV\n";
    std::cout << "  Detected in muon chamber: "
      << muon_chamber->measure_energy(p) << " keV\n";
  }
}
