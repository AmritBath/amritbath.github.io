// PHYS 30762 Programming in C++
// Author: 10899510 - Amrit Bath
// Date: April 2025
// Interactions header file

#pragma once

#include "../Particles/Photon.h"
#include "../Particles/Electron.h"

// Simulates the photoelectric effect
double photoelectric_effect(const Photon& p);

// Simulates Compton scattering at a specified angle
void compton_scattering(Photon& p, double angle_deg);

// Simulates pair production if energy conditions are met
std::vector<std::shared_ptr<Electron>> pair_production(const Photon& p);

