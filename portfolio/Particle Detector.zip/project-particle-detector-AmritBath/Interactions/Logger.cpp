// PHYS 30762 Programming in C++
// Author: 10899510 - Amrit Bath
// Date: April 2025
// Logger class implementation
// Description: Implementation of the Logger class, which is responsible for logging particle detection events
// in a CSV file. It includes methods for initializing the logger, logging detection events, and closing the log file.

#include "Logger.h"

// Logger class constructor
Logger::Logger(const std::string& filename) 
{
  file.open(filename);
  if(file.is_open()) 
  {
    file << "Particle,Energy(MeV),Detector,Detected\n"; 
  }
}

// Logger class destructor
Logger::~Logger() 
{
  if(file.is_open()) 
  {
    file.close();
  }
}

// Log detection events
void Logger::log_detection(const std::string& particle_type,
         double energy,
         const std::string& detector_name,
         bool detected) 
         {
  if(file.is_open()) 
  {
  file << particle_type << ","
     << std::fixed << std::setprecision(3) << energy << ","
     << detector_name << ","
     << (detected ? "1" : "0") << "\n";
  }
}