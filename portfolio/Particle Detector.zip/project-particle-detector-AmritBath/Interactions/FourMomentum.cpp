// PHYS 30762 Programming in C++
// Author: 10899510 - Amrit Bath
// Date: April 2025
// FourMomentum class implementation
// Description: Implementation of the FourMomentum class, which represents a four-momentum vector in special relativity. 

#include "FourMomentum.h"

// FourMomentum class constructor
FourMomentum::FourMomentum()
  : energy(0.0), px(0.0), py(0.0), pz(0.0) 
  {

  }
  
// FourMomentum class constructor with parameters
FourMomentum::FourMomentum(double e, double px, double py, double pz)
  : energy(e), px(px), py(py), pz(pz) 
  {

  }

// Static method to create a FourMomentum object from mass and velocity
FourMomentum FourMomentum::from_mass_and_velocity(double mass, double vx, double vy, double vz) 
{
  const double c = 3.0e8; // m/s
  double v_squared = vx*vx + vy*vy + vz*vz;
  double beta_squared = v_squared / (c * c);
  double gamma = 1.0 / std::sqrt(1 - beta_squared);

  double momentum_x = gamma * mass * vx;
  double momentum_y = gamma * mass * vy;
  double momentum_z = gamma * mass * vz;
  double total_energy = gamma * mass;

  return FourMomentum(total_energy, momentum_x, momentum_y, momentum_z);
}

// Static method to create a FourMomentum object from energy and momentum
double FourMomentum::get_energy() const 
{ 
  return energy; 
}
double FourMomentum::get_px() const 
{ 
  return px; 
}
double FourMomentum::get_py() const
{
   return py; 
  }
double FourMomentum::get_pz() const 
{ 
  return pz; 
}

double FourMomentum::spatial_magnitude() const 
{
  return std::sqrt(px*px + py*py + pz*pz);
}

double FourMomentum::invariant_mass() const 
{
  return std::sqrt(energy*energy - px*px - py*py - pz*pz);
}

double FourMomentum::dot(const FourMomentum& other) const 
{
  return energy * other.energy - (px * other.px + py * other.py + pz * other.pz);
}

// Method to add two FourMomentum objects
void FourMomentum::print() const 
{
  std::cout << "Four-Momentum: (E = " << energy
    << ", px = " << px
    << ", py = " << py
    << ", pz = " << pz << ")\n";
}
