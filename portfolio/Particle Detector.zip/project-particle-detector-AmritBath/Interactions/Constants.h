// PHYS30762 Programming in C++
// Constants header file
// Author: 10899510
// Date: April 2025

#ifndef CONSTANTS_H
#define CONSTANTS_H

const double LIGHT_SPEED = 2.99792458e8; // m/s 
const double BELOW_LIGHT_SPEED = 2.99792457e8; // m/s - just below speed of light
const double ELECTRON_MASS = 0.511; // MeV
const double MUON_MASS = 106; // MeV - rounded to nearest MeV
const double TAU_MASS = 1777; // MeV - rounded to nearest MeV
const double PROTON_MASS = 938.272; // MeV - rounded to nearest MeV
const double NEUTRON_MASS = 939.565; // MeV - rounded to nearest MeV

#endif // CONSTANTS_H
