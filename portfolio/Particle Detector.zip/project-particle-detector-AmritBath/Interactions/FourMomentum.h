// PHYS 30762 Programming in C++
// Author: 10899510 - Amrit Bath
// Date: April 2025
// FourMomentum header file

#pragma once
#include "../common_includes.h"

class FourMomentum 
{
private:
  double energy; 
  double px, py, pz; 

public:
  // Constructor
  FourMomentum(double energy, double px, double py, double pz);

  // Factory constructor from mass and 3-velocity (assumes uniform direction)
  static FourMomentum from_mass_and_velocity(double mass, double vx, double vy, double vz);

  // Accessors
  double get_energy() const;
  double get_px() const;
  double get_py() const;
  double get_pz() const;

  // Derived quantities
  double spatial_magnitude() const;
  double invariant_mass() const;

  // Operations
  double dot(const FourMomentum& other) const;
  void print() const;

  FourMomentum();
};