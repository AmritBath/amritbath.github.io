// PHYS 30762 Programming in C++
// Author: 10899510 - Amrit Bath
// Date: April 2025
// Logger header file


#pragma once
#include "../common_includes.h"

class Logger 
{
private:
  std::ofstream file;

public:
  // Constructor and destructor
  Logger(const std::string& filename);
  ~Logger();

  void log_detection(const std::string& particle_type,
       double energy,
       const std::string& detector_name,
       bool detected);
};
