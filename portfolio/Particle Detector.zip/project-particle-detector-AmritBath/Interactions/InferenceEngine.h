// PHYS 30762 Programming in C++
// Author: 10899510 - Amrit Bath
// Date: April 2025
// InferenceEngine header file
// Description: Implementation of the InferenceEngine class, which is responsible for inferring the type of particle
// based on the hits in different detectors. It provides a static method to determine the particle type based on
// the presence of hits in the tracker, calorimeter, and muon chamber.


#pragma once
#include "../common_includes.h"

class InferenceEngine 
{
public:
  static std::string infer_particle(bool tracker_hit, bool calo_hit, bool muon_hit) 
  {
    // Inference logic based on detector hits
    if(tracker_hit && calo_hit && muon_hit)
      return "tau or high-energy muon (exotic track)";
    else if(tracker_hit && calo_hit)
      return "electron";
    else if(tracker_hit && muon_hit)
      return "muon";
    else if(tracker_hit && !calo_hit && !muon_hit)
      return "light charged particle (e.g., pion or low-energy muon)";
    else if(muon_hit && !tracker_hit && !calo_hit)
      return "muon (missed tracker)";
    else if(!tracker_hit && !calo_hit && !muon_hit)
      return "neutrino or neutral particle";
    else
      return "unknown (ambiguous signature)";
  }
};
