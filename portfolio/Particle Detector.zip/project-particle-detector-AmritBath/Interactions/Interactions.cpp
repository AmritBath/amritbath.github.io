
// PHYS 30762 Programming in C++
// Author: 10899510 - Amrit Bath
// Date: April 2025
// Interactions.cpp
// Description: Implementation of the Interactions class, which simulates various particle interactions
// including photoelectric effect, Compton scattering, and pair production.

#include "Interactions.h"

#define PINKRED "\033[38;5;198m"
#define RESET   "\033[0m"

// Simulates the photoelectric effect and returns the energy of the incoming photon
double photoelectric_effect(const Photon& p) 
{
  return p.get_energy();
}

// Simulates Compton scattering of a photon with a scattering angle in degrees
// and updates the photon's energy
void compton_scattering(Photon& p, double angle_deg) 
{
  double theta = angle_deg * M_PI / 180.0;
  double E = p.get_energy();
  double me = 511.0; 
  double new_E = E / (1 + (E / me) * (1 - std::cos(theta)));
  p.set_energy(new_E);
  std::cout << "After Compton scattering, new photon energy: " << new_E << " keV\n";
}

// Simulates pair production if photon energy exceeds 1.022 MeV
std::vector<std::shared_ptr<Electron>> pair_production(const Photon& p) 
{
  double me = 511.0; // keV

  if(p.get_energy() > 2 * me) 
  {
    double e = p.get_energy() / 2;
    auto e1 = std::make_shared<Electron>(e);
    auto e2 = std::make_shared<Electron>(e);

    // Associate electrons with the photon that created them
    const_cast<Photon&>(p).add_electron(e1);
    const_cast<Photon&>(p).add_electron(e2);
    std::cout << "Created pair electrons:\n";
    std::cout << "  -> " << e1->get_type() << "\n";
    std::cout << "  -> " << e2->get_type() << "\n";

    return 
    { 
      e1, e2 
    };
  } 
  else 
  {
    std::cout << PINKRED << "ERROR: Insufficient energy for pair production.\n" << RESET;
    return 
    {

    };
  }
}
