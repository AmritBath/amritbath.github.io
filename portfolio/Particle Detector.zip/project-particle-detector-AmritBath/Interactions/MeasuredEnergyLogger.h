// PHYS 30762 Programming in C++
// Author: 10899510 - Amrit Bath
// Date: April 2025
// MeasuredEnergyLogger header file

#pragma once
#include "../Particles/Particle.h"
#include "../Detector/Detector.h"

class MeasuredEnergyLogger 
{
public:
  /// Function to log the energy report of particles
  static void log_energy_report(
    const std::vector<std::shared_ptr<Particle>>& particles,
    const std::shared_ptr<Detector>& tracker,
    const std::shared_ptr<Detector>& calorimeter,
    const std::shared_ptr<Detector>& muon_chamber);
};
