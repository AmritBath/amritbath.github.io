// PHYS 30762 Programming in C++
// Author: 10899510 - Amrit Bath
// Date: April 2025
// DetectorManager header file
// Composite wrapper for multiple detectors

#pragma once

#include "Detector.h"
#include "../Particles/Particle.h"

// DetectorManager class to manage multiple detectors
class DetectorManager 
{
private:
  std::vector<std::shared_ptr<Detector>> detectors;

public:
  void add_detector(const std::shared_ptr<Detector>& detector);
  void detect_all(const std::shared_ptr<Particle>& particle);
  void print_all() const;
  void turn_all_on();
  void turn_all_off();
};
