// PHYS 30762 Programming in C++
// Author: 10899510 - Amrit Bath
// Date: April 2025
// Detector class implementation
// Description: Implementation of the Detector class, which serves as a base class for various detectors
// in a particle detection system. It includes methods for turning the detector on/off, detecting particles,
// and printing configuration data.

#include "Detector.h"

// Constructor for Detector
Detector::Detector(const std::string& detector_type,
   double efficiency,
   const std::string& material_type,
   int num_layers,
   double volume_cm3)
  : type(detector_type),
  is_on(false),
  detected_particles(0),
  detection_efficiency(efficiency),
  dist(0.0, 1.0),
  material(material_type),
  layers(num_layers),
  sensitive_volume_cm3(volume_cm3) 
  {
  std::random_device rd;
  rng = std::mt19937(rd());
}

Detector::~Detector() = default;

// Turn the detector on
void Detector::turn_on() 
{
  is_on = true;
}

// Turn the detector off
void Detector::turn_off() 
{
  is_on = false;
}

// Get the type of the detector
std::string Detector::get_type() const 
{
  return type;
}

// Get the number of detected particles
int Detector::get_detection_count() const 
{
  return detected_particles;
}

// Measure the energy of a detected particle
void Detector::print() const 
{
  std::cout << "Detector Type: " << type
  << "\nStatus: " << (is_on ? "ON" : "OFF")
  << "\nParticles Detected: " << detected_particles << "\n";
}

// Print the configuration of the detector
void Detector::print_configuration() const 
{
  std::cout << "  Material: " << material
  << "\n  Layers: " << layers
  << "\n  Sensitive Volume: " << sensitive_volume_cm3 << " cm³"
  << "\n  Detection Efficiency: " << detection_efficiency << "\n";
}
