// PHYS 30762 Programming in C++
// Author: 10899510 - Amrit Bath
// Date: April 2025
// Tracker class implementation
// Description: Implementation of the Tracker class, which is a type of detector that detects leptons and anti-leptons

#include "Tracker.h"

// Constructor for Tracker
Tracker::Tracker()
  : Detector("tracker", 0.9, "Silicon", 5, 1200.0) 
  {
    std::cout << "\033[32mConstructing detector\033[0m: tracker\n";
  }

// Destructor for Tracker
bool Tracker::detect(const std::shared_ptr<Particle>& particle) 
{
  if(!is_on) 
  {
    std::cout << "Tracker is OFF. Cannot detect particles.\n";
    return false;
  }

  auto lepton = std::dynamic_pointer_cast<Lepton>(particle);
  bool match = lepton && (lepton->get_type() == "electron" || lepton->get_type() == "muon" ||
             lepton->get_type() == "positron" || lepton->get_type() == "anti-muon");

  if(match && dist(rng) < detection_efficiency) 
  {
    std::cout << lepton->get_type() << " detected in tracker.\n";
    detected_particles++;
    return true;
  } else 
  {
    std::cout << particle->get_type() << " not detected in tracker.\n";
    return false;
  }
}

// Measure energy for the detected particle
double Tracker::measure_energy(const std::shared_ptr<Particle>& particle) const 
{
  return (particle->get_charge() != 0) ? particle->get_energy() * 0.6 : 0.0;
}
