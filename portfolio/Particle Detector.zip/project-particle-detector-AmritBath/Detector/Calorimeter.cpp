// PHYS 30762 Programming in C++
// Author: 10899510 - Amrit Bath
// Date: April 2025
// Description: Implementation of the Calorimeter class, which is a type of detector

#include "Calorimeter.h"

// Constructor for Calorimeter
Calorimeter::Calorimeter()
  : Detector("calorimeter", 0.7, "Lead tungstate", 10, 5000.0) 
  {
  std::cout << "\033[32mConstructing detector\033[0m: calorimeter\n";
}

// Destructor for Calorimeter
bool Calorimeter::detect(const std::shared_ptr<Particle>& p) 
{

  if(!is_on) return false;

  std::string type = p->get_type();
  bool detected = (type == "electron" || type == "positron");

  if(detected) 
  {
    double absorption_fraction = 0.6 + static_cast<double>(rand()) / RAND_MAX * 0.2;
    double original_energy = p->get_initial_energy();  // use true initial energy
    double current_energy = p->get_energy();
    double raw_proposed = original_energy * absorption_fraction;
    double deposited_energy = std::min(current_energy, raw_proposed); 

    true_energy_deposited += deposited_energy;

    double smear_factor = std::max(0.0, static_cast<double>(std::normal_distribution<>(1.0, 0.1)(rng)));
    double smeared_energy = deposited_energy * smear_factor;
    measured_energy_map[p->get_id()] = std::min(smeared_energy, current_energy);  // clipped to remaining
    measured_energy += measured_energy_map[p->get_id()];

    p->set_energy(current_energy - deposited_energy);   

    detected_particles++;

    std::cout << type << " deposited " << deposited_energy << " keV in calorimeter.\n";
  }

  return detected;
}


double Calorimeter::measure_energy(const std::shared_ptr<Particle>& p) const 
{
  // If nullptr passed, return total energy for detector summary
  if (!p) return measured_energy;

  auto it = measured_energy_map.find(p->get_id());
  return (it != measured_energy_map.end()) ? it->second : 0.0;
}
