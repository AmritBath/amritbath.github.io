// PHYS 30762 Programming in C++
// Author: 10899510 - Amrit Bath
// Date: April 2025
// MuonChamber class header file - with layered sub-detectors

#pragma once

#include "Detector.h"
#include "SubDetector.h"
#include "../Particles/Lepton.h"

class MuonChamber : public Detector 
{
private:
  std::shared_ptr<SubDetector> drift_tube;
  std::shared_ptr<SubDetector> resistive_plate;

public:
  MuonChamber();
  bool detect(const std::shared_ptr<Particle>& particle) override;
  double measure_energy(const std::shared_ptr<Particle>& particle) const override;
};