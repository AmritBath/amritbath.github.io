// PHYS 30762 Programming in C++
// Author: 10899510 - Amrit Bath
// Date: April 2025
// DetectorManager class implementation
// Description: Implementation of the DetectorManager class
// which manages multiple detectors in a particle detection system.

#include "DetectorManager.h"

// Constructor for DetectorManager
void DetectorManager::add_detector(const std::shared_ptr<Detector>& detector) 
{
  detectors.push_back(detector);
}

// Destructor for DetectorManager
void DetectorManager::detect_all(const std::shared_ptr<Particle>& particle) 
{
  for(const auto& detector : detectors) 
  {
    detector->detect(particle);
  }
}

// Measure energy for all detectors
void DetectorManager::print_all() const 
{
  for(const auto& detector : detectors) 
  {
    detector->print();   
    detector->print_configuration(); 
    std::cout << "\n";
  }
}

// Turn all detectors on
void DetectorManager::turn_all_on() 
{
  for(auto& detector : detectors) 
  {
    detector->turn_on();
  }
}

// Turn all detectors off
void DetectorManager::turn_all_off() 
{
  for(auto& detector : detectors) 
  {
    detector->turn_off();
  }
}
