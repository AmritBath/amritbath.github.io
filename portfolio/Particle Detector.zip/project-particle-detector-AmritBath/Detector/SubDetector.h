/// PHYS 30762 Programming in C++
// Author: 10899510 - Amrit Bath
// Date: April 2025
// SubDetector header file
// Description: Header file for the SubDetector class, which represents a sub-detector in a particle detection system.

#pragma once
#include "../common_includes.h"

class SubDetector 
{
private:
  std::string name;
  double efficiency;
  mutable std::uniform_real_distribution<> dist;

public:
  SubDetector(const std::string& name, double eff)
    : name(name), efficiency(eff), dist(0.0, 1.0) 
    {
      
    }

  bool try_detect(std::mt19937& rng) const 
  {
    return dist(rng) < efficiency;
  }

  std::string get_name() const 
  {
     return name; 
    }
  double get_efficiency() const 
  {
     return efficiency; 
    }
};
