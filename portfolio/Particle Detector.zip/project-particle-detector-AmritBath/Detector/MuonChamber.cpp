// PHYS 30762 Programming in C++
// Author: 10899510 - Amrit Bath
// Date: April 2025
// MuonChamber class implementation - with layered sub-detectors

#include "MuonChamber.h"

// Constructor: initialise two sub-detectors with distinct efficiencies
MuonChamber::MuonChamber()
  : Detector("muon chamber", 0.92, "Composite (DT + RPC)", 16, 4200.0) 
{
  std::cout << "\033[32mConstructing detector\033[0m: muon chamber\n";

  // Initialise layers with specific efficiencies and types
  drift_tube = std::make_shared<SubDetector>("DriftTube", 0.85);
  resistive_plate = std::make_shared<SubDetector>("ResistivePlate", 0.90);
}

// Attempt detection with both internal layers
bool MuonChamber::detect(const std::shared_ptr<Particle>& particle) 
{
  if(!is_on) 
  {
    std::cout << "Muon chamber is OFF. Cannot detect particles.\n";
    return false;
  }

  auto lepton = std::dynamic_pointer_cast<Lepton>(particle);
  bool is_muon = lepton && (lepton->get_type() == "muon" || lepton->get_type() == "anti-muon");

  if(!is_muon) 
  {
    std::cout << particle->get_type() << " not detected in muon chamber.\n";
    return false;
  }

  bool hit_drift = drift_tube->try_detect(rng);
  bool hit_rpc = resistive_plate->try_detect(rng);

  if(hit_drift || hit_rpc) 
  {
    std::cout << lepton->get_type() << " detected in muon chamber (";
    if(hit_drift) std::cout << "DriftTube";
    if(hit_drift && hit_rpc) std::cout << "+";
    if(hit_rpc) std::cout << "ResistivePlate";
    std::cout << ")\n";
    detected_particles++;
    return true;
  }

  std::cout << lepton->get_type() << " not detected in muon chamber.\n";
  return false;
}

// Return estimated measured energy for muons
double MuonChamber::measure_energy(const std::shared_ptr<Particle>& particle) const 
{
  return particle->get_type().find("muon") != std::string::npos
    ? particle->get_energy() * 0.7
    : 0.0;
} 