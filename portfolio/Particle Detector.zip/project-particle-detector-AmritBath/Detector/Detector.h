// PHYS 30762 Programming in C++
// Author: 10899510 - Amrit Bath
// Date: April 2025
// Detector header file

#pragma once
#include "../Particles/Particle.h"

class Detector 
{
protected:
  std::string type;
  bool is_on;
  int detected_particles;

  // Detection parameters
  double detection_efficiency;
  std::mt19937 rng;
  std::uniform_real_distribution<> dist;

  // Physical configuration
  std::string material;
  int layers;
  double sensitive_volume_cm3;

  double true_energy_deposited = 0.0;
  double measured_energy = 0.0;

  std::map<int, double> measured_energy_map;

public:
  // Constructor
  Detector(const std::string& detector_type,
     double efficiency,
     const std::string& material_type,
     int num_layers,
     double volume_cm3);
  
  virtual ~Detector();
  
  // Detector methods
  void turn_on();
  void turn_off();
  virtual bool detect(const std::shared_ptr<Particle>& particle) = 0;

  virtual void print() const;
  virtual void print_configuration() const;  

  std::string get_type() const;
  int get_detection_count() const;

  virtual double measure_energy(const std::shared_ptr<Particle>& particle) const = 0;
  double get_true_energy() const { return true_energy_deposited; }
  

};
