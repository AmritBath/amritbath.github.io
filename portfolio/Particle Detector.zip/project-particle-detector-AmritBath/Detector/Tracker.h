// PHYS 30762 Programming in C++
// Author: 10899510 - Amrit Bath
// Date: April 2025
// Tracker header file

#pragma once

#include "Detector.h"
#include "../Particles/Lepton.h"

// Tracker class inherits from Detector
class Tracker : public Detector 
{
public:
  Tracker();
  bool detect(const std::shared_ptr<Particle>& particle) override;
  double measure_energy(const std::shared_ptr<Particle>& particle) const override;
};
